package com.example.weidumovie_one.application;

import android.content.Context;

import com.example.lib_core.appclition.BaseApp;
import com.letv.sarrsdesktop.blockcanaryex.jrt.BlockCanaryEx;
import com.letv.sarrsdesktop.blockcanaryex.jrt.Config;
import com.squareup.leakcanary.LeakCanary;

public class App extends BaseApp {
    @Override
    public void onCreate() {
        super.onCreate();
        initLeakCanary(); // 内存检测框架
    }

    /**
     * 当应用程序attachBaseContext时，在其他方法之前初始化BlockCanaryEx
     *
     * @param context
     */
    @Override
    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        boolean isInSamplerProcess = BlockCanaryEx.isInSamplerProcess(this);
        if (!isInSamplerProcess) {
            BlockCanaryEx.install(new Config(this));
        }
        if (!isInSamplerProcess) {
            // 自己的代码从这里开始
        }
    }

    private void initLeakCanary() {
        if (LeakCanary.isInAnalyzerProcess(this)) {
            // This process is dedicated to LeakCanary for heap analysis.
            // You should not init your app in this process.
            return;
        }
        LeakCanary.install(this);
        // Normal app init code...
    }
}
