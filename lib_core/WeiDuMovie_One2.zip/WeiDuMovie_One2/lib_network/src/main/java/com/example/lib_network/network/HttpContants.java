package com.example.lib_network.network;

/**
 * http状态吗，http协议相关的常量
 */
public class HttpContants {
    //服务器约定好的常量
    public static String SUCCESS ="0000";//请求成功
    public static String ERROR ="1111";//请求失败,服务端约定的返回码
}
