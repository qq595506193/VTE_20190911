package com.example.lib_network.bean;

public class BaseResponseBean<T> {
    public String message;
    public String status;
    public T result;
}
