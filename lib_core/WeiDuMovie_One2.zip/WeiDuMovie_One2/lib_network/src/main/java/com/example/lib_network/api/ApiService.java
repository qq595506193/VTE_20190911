package com.example.lib_network.api;

public class ApiService {
    public static final String BASE_URL = "http://172.17.8.100/small/";
    public static final String IM_BASE_URL = "http://172.17.8.100/im/";


}
