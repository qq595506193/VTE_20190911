package com.example.lib_core.base.mvp;

/**
 * 基类model
 */
public interface IBaseModel {

}
