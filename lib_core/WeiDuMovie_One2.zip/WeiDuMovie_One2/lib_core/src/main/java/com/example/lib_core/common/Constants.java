package com.example.lib_core.common;

public class Constants {
    public static boolean IS_RELEASE = false;//环境开关
}
