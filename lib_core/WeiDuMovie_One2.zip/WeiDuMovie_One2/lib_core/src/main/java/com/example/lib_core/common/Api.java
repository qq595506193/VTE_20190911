package com.example.lib_core.common;

/**
 * 接口管理类
 */
public class Api {
    public static final String BASE_URL = "http://172.17.8.100/";
}
